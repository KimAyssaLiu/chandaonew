<?php include '../../common/view/header.lite.html.php';?>
<table class='table-1' style='margin-top:100px;'>
  <caption><?php echo $lang->misc->mobile?></caption>
  <tr><td><?php echo $noGDLib?></td></tr>
</table>
<?php include '../../common/view/footer.lite.html.php';?>
