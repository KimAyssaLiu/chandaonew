<?php //0067d
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}
$documentRoot = isset($_SERVER['SCRIPT_FILENAME']) ? dirname($_SERVER['SCRIPT_FILENAME']) : $_SERVER['DOCUMENT_ROOT'];
$link = is_file($documentRoot . '/loader-wizard.php') ? '/loader-wizard.php' : 'http://www.ioncube.com/lw/';
echo "<html>
  <head>
    <meta http-equiv='content-type' content='text/html; charset=utf-8' />
    <title>error</title>
  </head>
  <body>
    <h2 style='color:red;text-align:center'>未安装 ioncube loader</h2>
    <p>您需要安装ioncube loader才能使用该功能， 使用<a href='$link'>ioncube loader安装向导</a>。</p>
    <br /><br /><br />
    <h2 style='color:red;text-align:center'>Ioncube loader doesn't installed.</h2>
    <p>You haven't installed ioncube loader extension, please visit <a href='$link'>the install wizard</a> to install it.</p>
  </body>
</html>";
exit;

?>
HR+cPxstrBEVc2s4tWH1aAh8yVCHz8TlQumOKs2KAxOtvNOKyKuOzkxoSeHf91DGxuM2DzNgBINr
Br1uk0OqpRZxR9cdCqb4tEpGRRGFIyja9lw9BIue2pBYe1ekIgG+Y1oIqP6qqepSpxT2cVV39MJD
U9bzFbMVLSti0HumFr/+BfAwDf1JL6XYCrlgNZLIvca6S9N36yG3ha8j6ZwQo1MYZkNHvT+DBZLs
AZApBSxjAuU92sq4J7lgyuVPjIcTGeD90wR/d8TfAI87pGNchu5IcE/CffA+QiFBlmVcHLrEjsSJ
SYN0PmvGYQRyOAQ73tyQXQcjwjYeZ0BmaH01vexK43JHeq6QqICSq2sBSSNpWGQF3DGIE4++FJSt
to/uziYB/p8NiVBWxSU1eh7cxRWagYEJ7ECv9eHPn2YJXIEYtMR0mypkvZ0FanJY4zylxlmjbJAt
Aoo4R92Pl45XyziijLM7yZNLVYof+8q5vrpi4Q2HJEbOsvu3M4SqsWlBIGMSWQbLXmBJ5uo1qN0N
8lprdJ/LvPKHigzwmiUF1SnnE6tFPXS9Qt8UL8ZiGTBPQ+TYAyPNDf8mQLeKcGlz1ArLeZrODCil
Ih9KRgIMvpCGPHFbliIHAIsR86HkX01gLAFslFUNIySt/n1yItr/WrHzTxZctOZVpY/Mo2jZlzYG
04mz/akWmOaLj8n5kv59eNAeAGQyN/xBk1gMoF6GthfoqOqmFYGbeVV/8f1nUpKL1u/EM17/d0iM
0AtB1zX3UeT+veeuUBNF9/2QeHMl6TAgg9vMPg+fQ5LeJEnpBdiR0II+Kflz4E9gTIP/HvCN/EEP
/oRNHD7G1/hc4PUZZ58TbvCCYtE4w7ZEwJJZopQjsqXO/pRBg+88UymM9FY0u6BE/lsp/BYumDQr
6doTjm5GwuHhrQuCbRWRO5mC9Hk29hgEafMpkyt/JaxToGaZQ7AR4D2gD6lF59xmQHydS7ujkyPf
xPX92Bjf8t6Qv+wfGOnYFrn4fIDqAa7OHf2Si2b4X1xtAjI2Hi01z86RMPwjOik5+R3/L+LaBAu1
FTGbo3WBdEzjNXU5ZP2LIgrnKOUGw/T59PhoB7Tw76TulAtWUn7uDDVqr1RN4MC1rriTZPhbcYbW
ISLL1cbw3TGhr042O3Gcaf0EEdHyXx2yl3Le1ysF9drMcA+cG/WQ7uTk/XHcGpitjX42/yXkGHTF
aVMgaSwyq/XfKx9dz49rzvsqUABcDaZleKL6vFvFfU1RtHecqkYjMpSlw+JC0yXQIKTZVIza/1pO
V73w1yMKm0+SXJbMP3HJyIasJ0H6Y3Xa5Nwp14EBY+S0bdiZmDQrPCsopNf/7+MVRiHdIUp/MSNQ
97TXQCknXmfqVO61gh7mC+XlEjJ32w0AnGmuHWSLboekICx0+vh7leBDnX1R4fIq9uPggIABTje6
/nCL1he5iTcZDShPZx3eL91QA1UXXeCaBFY60r1s19h+hUuGVAi2vIwZuwTcbLQQUdqCNd7pHxzX
7oDBbc8eC/JewF213DyQG9Plb2i5iaGiLOnyjuduIPoo2mEVfegBYH67jKESMpOP44yHL0NJ4KH7
sL7H5wpSsmTnzesEbcoYlh/zgcIRX5GwFXmOOLRAGAVQjCvuHJWDbS/ppPXczgyI+U4AG8Na8xZS
g5tzdv4eb0ZhDcdKRoX+d4hp3AgmNXuBYzDyc84sTlBp0m+K97WJaAwTS4lUy0QY05bQyga0dsGg
qKrI0vzbMGbVTqpMc5oaWGKs5xsKCgFwLML1SLeYqBfBaCkEyqyrW/vLonewZ1zIZ7h8waJ/BnfJ
SuPVYHaCfvgUS38NKKWT6o25ELogm32oyOk5ZjVsDXu1IQ0mvRPbYjUhrn59TWDYc6YwxGBHrANE
yq5gev0S4Acsqc1JjUm0jMmOcFTRa9XRBikxT9NqfQWXacVa/XaNurMnp2cFQj0B02XsjPg/mPqe
43aJMz10LKNBt/UhoVlJeLYSZMJAKQwOvhRY3UBdiaP6pdMwRQed+EQZlxycJ3vR5oslWKFy9unK
QO1vMQarKL4pBsYXFmmxLGmTvtsfhv3tRMujoqPxV9+jAyWYReVi9U3PEOiolTspvzIqW171p4zu
wZjvLdQzClyJAeIG+NfXllFbSR4JAlEv2pFLD7ZaAzQnwtCcv5RQCY+OxgJ3+cjKDLQGCqz7Djya
hP8gJNhHzoWwroEODMo78XKI8WfbnonbX4RGOJcIEklLkO/lWD22TxEaEvu63joCMqDxEWYDnm6I
rZCElNW61k2oecovMbyOwXoi9XXbiKc6QpdLknp4gnipg1CdYdgQX+DYPOx4aw3JKgDAE43uUGac
xl1nq23PyX4zzTe/e4f/VeAM9qtqV0y4NTpfWggssyKKY8xix8p9PlZHcEF9PFxEidpm5MAZMatv
cYM/RLJWRyUkfOKrjPlBwaeZu54glRaUAlNvprjlk84Hmo8c/wR2ts8mdAFBaqJjQtmGaxgMorvU
0BYIHRptS4bphBuDpKfwLitLE0OzTwJNuabbV6A/l56ad4c/62EmJrlQHzEoG5xG+PIh2dbEilB5
GTzjDeMlmEzu7Z3WuhVS9RcYFdNWnMgEJYiNKKox9mrRf2uJNsE9A61VMQr1PWYsfw7WTclA8b83
TxbDkKOwMv8SCYTciSy5QdZldamVDijX0wORIrvN9z8eYXvdhYNku88tPO8o6ZrMWZi3pwSM14bv
2UfYPPwzI/zV+p+zUlSmIXAtNnpEMllkkk0bMDIZMPMoTWbIjmltR0Are+Lg7N8uVFkJb1POS7dU
scfy7fy5D67GctclFNtXVOFMhS4+0xe+7t9GccFiUPc0lKvghhYQeBize52qMIHhju4k00bIESUj
GLpw+pyCD1ONYyN7ehiVXv5XbxeS6uK4/9fRlJyZMfJPSHMpIzK8PJQpXNHFQvLSCtcYBdlNIGrv
8hsiHQzj0JX2LYpQL4Ftf7rKmKFYqePt+1vN8SWemC9azlgvlqzbZV5poByAlOZj4J5oWAKdovUZ
e7uG9omVMzzlwo4TMxSphWg/pGD9hbxsTQ931FWpi+KzhZKI2bfelCAtwoeidxextOh4