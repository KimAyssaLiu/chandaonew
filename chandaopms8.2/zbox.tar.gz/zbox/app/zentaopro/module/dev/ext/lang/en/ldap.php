<?php
$lang->dev->tableList['ldap'] = 'LDAP';
