<?php
$lang->user->effort = '日志';
$lang->user->select = '请选择用户';
