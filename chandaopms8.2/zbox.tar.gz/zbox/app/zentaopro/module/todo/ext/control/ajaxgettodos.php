<?php //0067d
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}
$documentRoot = isset($_SERVER['SCRIPT_FILENAME']) ? dirname($_SERVER['SCRIPT_FILENAME']) : $_SERVER['DOCUMENT_ROOT'];
$link = is_file($documentRoot . '/loader-wizard.php') ? '/loader-wizard.php' : 'http://www.ioncube.com/lw/';
echo "<html>
  <head>
    <meta http-equiv='content-type' content='text/html; charset=utf-8' />
    <title>error</title>
  </head>
  <body>
    <h2 style='color:red;text-align:center'>未安装 ioncube loader</h2>
    <p>您需要安装ioncube loader才能使用该功能， 使用<a href='$link'>ioncube loader安装向导</a>。</p>
    <br /><br /><br />
    <h2 style='color:red;text-align:center'>Ioncube loader doesn't installed.</h2>
    <p>You haven't installed ioncube loader extension, please visit <a href='$link'>the install wizard</a> to install it.</p>
  </body>
</html>";
exit;

?>
HR+cPt9bfMysv1r0TwimJCIxD+iBXnq0RDL+hEt53KExzQTHOkeYPZZvLYVIX3swCwf4L2Q4pWxk
9aVkxBjdVZ9LXJWCZYgX3bmA+Jh+7pws0y5G/Gf4D4aJhl1vKsXH53HLBJvje/LdPySiE/0jHNAp
7jLJeGsVYY1p55i9KVcoV+so4B09FSJxV0LFMLX0BT2AfuuN0KYNzcZuRNw34j6ceDxT58Sl3QYJ
1Sv412RV9H3hImWXYgb/HOCk/XTtmFDAl+YIzbEBtZgTcn+8AcNYtRautzPHmJW60ritNWwIaORa
BQrMyVb7kZtJzCrifCa+/DsKVcB5v9qcGvj3dcYvL3wEpqqOjEzi30dTblE11g0Cr18uJxuzDpVV
B/ZsXuLiJaaAS+H2bB8xOVhjk49eM0t88tt+x7zbZiuACq0vKYg8biiZX/qFMfU8DpO6e9xMSmX1
wLjjBaiQO3jTxxDMDva57kcMeC58/NsqtyDIi5eklhOf4pCd7ZksATvHiQOT3sFiw2ZehKZtKBlw
bKkGIOKZvTrnCL+2ysQMRA5G9ehiGaKYjigjuSqkPNw8muOXJIewBlkqhxYj5FqCTatTXpt+UYnZ
ty/47jEwsHbZJdqlKalNpKzCX2JTkdpNEblrI52ENMi2shfV+f8kSyU54uiWrSiLv3Y7L9S1bMfL
tlFIw9VB7+UsFsZCK+yNsIryMRd2Em+4/gBbhQWEbjjBY1sLvlxJlyrTWC8t8NZxVpiE1rH+gwJx
K80Se/I4fER1YPqxQUarVmS6I5VOpvPS/KeDRy+p+ps1cuOw21xVS7MPwYfgvUsN+WIFlPkUENGz
MJGeSS2+uZBf0x4EDZyPjYirBY1FJhI7So1FvBdQbLi+n6pxuSCIEwHH3kdXZtdaCcNdinp9+ZI5
Daqk8kPT1JaCYv4ad5rA9LnbNIVfyQ868xe3ZZD94szKDainsRPBycQcc4p/i8cQ/e1n7bffw07f
wbPiFbNApwOVM8n7eY1ceZ8AEh9O7q9uM+FQ6af5MnKDL1U7BNpFJj2OirO9A0muVwtQnp/mCgSj
2O2zdfjGUEqi39R+IFP4HU7FZNWaJ4CC3WdaxwyQ/yzxYdWL+8S86PCBLUrA+CVvPsBzbN+vhTOP
Ae+BvYi7MWf8VMS1LVNnSbtKQDn+dpf74IfuLz/Bsy1jmYefJ19xXQs5Q43yNhIKlCa68HxojH5P
OjXlLgZD4iUSCH96sqQBXcPGhnFPnx1a1THqhlKoTvq0hdhhFmhH6dNBAdF0rD6vYzg/YVDtYYSB
4EWj+yeBd8ObqXpUNw2GmchgURDNKj3IQRMsBktSmjlL4fEPyCWg+72MYI6DoH46CaZZwIzCZ9ta
FQn272yaMQpl4D6imGezo7tPZ/NPuAH+lBljHlwM52D89er7exJf4ddu6OmeA+3VwKdl0/+UmeWo
7Gp/9EnOD47mrQm3ZqVmPiQWc8evDNkt4DXhW1Yb2C5v1XW5nao006zICLKMnpCcSKCUC4lo6S0h
Ss3FAbsihOh4XAtTr2B+sK89j0GZY8vOqZXSihvkOZULPsU1407BpvM77dp71ZAhb9x8fxRd2M4e
HJFMGqSKyjtemiaheKZ/YVTLDNVziaQkaz9UE44W3M8UCsx2Lo/85XIrn7tZZ4c+6OZslNOu6dAF
8revQM5SIKYWGap9jSAWK21U9rx6lfJ2Pqk8fQHN64UsyKQ3A6pkmC0bOf164XB4KCGOe6Qb4Lb+
6ggvsnPf6bRjqqeHzfgjagRwrwox4BdQDxaA9uiHDq6B9S5jz8o7IcDdXD/qrc307zV6qJy8Qv9s
AOGCdA16bkUKHcM90Xge7hZvIDFo3hQrOLJOfdBVBiy1jflm2TMIQ9Sj3A+ReXacixRA+FNlw0JU
wEX0c4rZAXRCAdCZhMQswkeU+e4DE2b6idkjTxYEs6EhXG3xLkGGRdrjgaqudxEc6UOLNdAHZZ+J
0WQKp06RH9n2yiNa3qrCVEPFmpN010NjnleSztfV5NVVBaPTc0OrUp4oYJSeDl+d9+kjO+0Fo/SL
6RFzvLR93q7a0QqRe02AHaLvG5tXU55pwBi6PYtcyHwPDfT0VDyCa7GRPuyH4QzQZ6WZ3VZjOetM
VsWZtpy3IXCmAvY7lK48JYt8mJST3MAiX5SAIGBcOHwkPb7zjLDQzD6/etiSu5Qk1G96bMsGwX8W
vHalOGHLf0EmohDnJfnAg2m6rF0MK6df2Kl2N2YwzwcIZN8FGrs/nQEzKdCiMUj7KuhMakaOGoHI
el7PAXCrnmDksgV9nqYxneGsqGYhlrefryyb+y2Zlva9NHe2Ol91GYrSYLyrcwSO21Angk/6p+iT
b8h0FaD8sBEOdsjUBgcLgeMDSXf5oKIEXpf4NoAKaTwU+nGI7JTvJj40KJRG3mZ0v4o0x8ueWZcx
OiEMk338RZRltNEl1AhtvLQxnyRR9nPH7p9qG+Rb0x6OeiYPpiGvLj4kgqPTKVK9Ysrq60buzynP
iaQGow9Hbln5bcFSSzliRghpy6iU2+R4V9om8mYfyY0s7kRhdQ3EQTwq0sdESOzauQKeh02jAtN3
J+kPwSKvT4JUX97O7kXJLC0AKCQYRHZfzXEuGDR0AnUa1Fl0SkiEtp2Sg99Jju4Nky/CGYED44uM
VdoeVOucp8lVQopGNEIWS9aE2NxDaOu+5dFWmTDGg4OzfzxlmQB04S9fZGCK+j1gxx7VQf5hmv/8
G6V20h0lphLX2JCu6Cs12QF0+IFTh5trFcKS7T5KkdnzU/pBTV58rTgIjqKH9viCy6kIQs6qqlV+
W3rpJIvu9nxPsZhcvUJrfkG6vMyQQedaf7wUHPiMxIt8AmZgiHD5QgRkBF/0yLTpft8zGG4WsJyC
Na0F98ZFuh1g07eDTuxCLWxil+oCT+xVjzvaEMhX2w6LWLDcacxavRRVy35AHUKJmhrdd9nIaoVR
7WSSKc9o6n6mD5Q512IGWQhfRkTml+mHWYR0AwpUuZc5fHk7DRYrBUOQBAFE0QAYPCDOl4fNP4uj
Ny6DogPOVAJJUmA/o8MPHqJHkzpBVVoSyiv00cxjUpyXBEUJs8bNAAZiC2r7fyhvJKuvGLe3u32w
HLTeb1pqUcCdpO3z5OqNAqXraTYnEYZCZfHeSuTT9nuR1P6Vk3GFs/tRWK8oPFFD37xjrEJUqMcg
qZCCLMK7QOiq//juzeiCuny0O3LkcyyBqCRsiSfwuK/UUXZ3XOVS9GgtodG+ZP0oelHD84q52ei4
o1O+4aWrvctIX40VkgSExxkzpmRb4r6sUjVpueZchlrwESO3pgi1EocKvE13S2LzRTahbVqVy8TS
B9M+zcivqKL1EiO5E8ARgLyPNrPoTLcQp/AfhPVs6Y5/CEvOtWmZM+RrG0oA4xy4jCuC1uooWv4L
xnK4Tn0dIZ1kgbXz+Rekffiiabreo+KIFjjcc/EBGefpEzDjMJXNi8hg7BW8qzPGOlPoP5+jvY+u
NIBUTdra7qu3waxX8NpslgkfP+4ZreLXhvZu1tALDuSBvnbl0tF/j1JRLbVNAqLeSLtz7y0VWB7n
p96Z/OLOeykvnJbu4vsPphbutwyxHaZZ838inXvYLPSKcnzkpHr3cxY97dRRN8Xttz5QnUvg8Rg+
Q6ETQI4/pSsnGeii/cBxoMVFfpWjuPPCxwns1a4T01XfXBdGefOoNPdN7Z+eQmC2eb9F+xn1zj1L
317+IRHALSIfMVTB3FBm6d2ulparjmQQHpRIM3fZPMap642QWo7lJ6XXLd/sxu08ke7DhzdywbsN
R7t0wHVf4dfBuDXGyYvlr4VVVcrxgUhJAKQE0PJfETQyHEVAOAdvRLl9IvnwuxC28WEDCQBuOwL/
FYL8exBxVqFBVmOI55o3V8wVuch4PTadI9BNh0DhHAEz5D3T/5CieZN2ohpmeeP7G/K/qJONtxrb
NMR4so8xHjjw2ylrev6fGr/k+7OnWpT6QMdnZrmQ1GkoaYbnoCn2T6qHBWkpESh5SDT8/tyOqMTi
8fwUygxyvsW3xNwLOQf3EyJibLCniXZGcwIXk8luNYMASNIbHzQAHm9gldrGzzhqu7DtLUUhpXrh
YMOUbVe73fLAjelwnPt+jyx+13NTm8oGSP1XYtFFicmuJD+tL1u8uTYrXT3IZRfHRJ9u