<?php
$lang->api->failLogin    = '登錄超時，請需要重新登錄！';
$lang->api->failNoFind   = '沒有該條記錄。';
$lang->api->failDeleted  = '該記錄已經刪除';
$lang->api->failComment  = '備註內容不能為空';
