<?php //0067d
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}
$documentRoot = isset($_SERVER['SCRIPT_FILENAME']) ? dirname($_SERVER['SCRIPT_FILENAME']) : $_SERVER['DOCUMENT_ROOT'];
$link = is_file($documentRoot . '/loader-wizard.php') ? '/loader-wizard.php' : 'http://www.ioncube.com/lw/';
echo "<html>
  <head>
    <meta http-equiv='content-type' content='text/html; charset=utf-8' />
    <title>error</title>
  </head>
  <body>
    <h2 style='color:red;text-align:center'>未安装 ioncube loader</h2>
    <p>您需要安装ioncube loader才能使用该功能， 使用<a href='$link'>ioncube loader安装向导</a>。</p>
    <br /><br /><br />
    <h2 style='color:red;text-align:center'>Ioncube loader doesn't installed.</h2>
    <p>You haven't installed ioncube loader extension, please visit <a href='$link'>the install wizard</a> to install it.</p>
  </body>
</html>";
exit;

?>
HR+cPtU9FoezMuGDW4Qg2GM+dV/yZTVzbrQR8NG+Uqs2X5obfDzUiihaz/fMAqGFFTDl0OodOP78
Z9cEwYSFWkTF/SB9chG44BFY8EeriAUkW8WB7QCMoepvGJP7fO6q6MB7beImhfuK+nl+B0ClQH2+
XyhYo+4+qHGE9WyaaFpui3gixIAqHfBGvAbBra6nZLjqH/5lHUaXaxHPyMwzToSh3iMqfWuqa11M
Kkyvf6QDlcZqLqi2RgH99CRlRwv+HvFvBS8DyiF3tKUgWr1MMdcnkpB5eRZCRyEevQ2j2DbolANM
ZAh38jdh+SuCCOoSInaYeRk4NRqo8NF/C0qtpZ/C4B9ItwcGlHUwISySL1RpWGQO3DGIE4++FJSt
to/uzYIGLg5ie7Eajdxfsj4+shXyGdHNl0/yGyk71y5MAXdeJiajygcJdDvW2TzjEDIMt9rCouqK
QWsDv2CqXw0Rfh/f+anyQOp4Ge2Z7OdlBj3rNSzHmvmJBhnfsr5UiWOrtbmwrcmoPR4JR+bNuFWp
ZLY3bfcxSIlcPANy6shhWL/07/Dedjvj4ENFnXLl4N5gqhjUaOrCrVYH72XWGn7nta9RfXPehyAz
FgT00JbFXuwMWGIOI/GNBVC8gueqvykgS25GJ/+mBrKUfzfJM/DXs5yqZNAo4GN7gqTl3JzkWFbw
jjQ8taP4eW2GoaIIRLFsTXcVVJTLGGSG4XI+q6ul/fEkpBwfjAdryFlRxIdvCLELhMX8sdh/waFU
mYNmb3GpQqn3y04/1tkv5ulVW4j/czL8zAwbhlpTYVda2g9Cz3dugY8z5KC4lFFJo3Bxanrwb+cQ
/JYxkCxAGleMD4OFnSTQLQfmeRKAKrGhVXO3HYh8MKftdmdOB3UosgvWntna7iWPO3Cf3Vmaec9v
jXoZIuYpBcQB8rsoSKDRP/nsVl227x7SwpZsgUeASgZ0yRg4VYrKZ5FWGuGiRQgV+CkQElAreHB2
eQWn8u6sxUAWEfd8ZkBhpYsJXH1WvtZuUPDNw2V5k5L3GP8nNCIujey/stJ1ezMUpmsL+BjRDcix
R5PC5VuH5HVqDzBSmWcS8/SH3f/8SRVcCb3bV33PB4dfSWGWHwMwVi7Rc428RHwzX97jIP5fKdB4
aw9e2CWXCmRPZ1hMfQc/gCpbKigb6LA9222VuTrldWGgiYxrmzQJjgsiwCs2BzBbGvBu2AuLYL36
RbxPWXWG0lhhhKh23HUF+v7pabWGAbsu21ulvgIQKL5QU9fd+wTu+wxLpq8d6yzuC+Z0m64UvSu9
zRhkOjUtzb53BWQscKmt5GkRLV5pSLw0JawuytexGo6utGNe27ZOvZt9NFVklcU6zKFu3lysP1uW
A/Ve5LhnWQVNZ7/3kqchVodFN9yt1DntdarIFtK7QahYpd37+q6g7yQJreaMvyXKV2dFyJ+Duojt
//YyUc7BQn9QaoKpneGKCQogpK5iocxMooNRqk5CMmK0cwaolKUmMJSaeXD6YxaKIg2CzCXuTfXs
stldA9WQtZf+S2EANajN9rruKC0LfQlfZgnK5wPlE2DR3ugYRpR4iz5XeQjZvyzeGLQ3P3Z7NSh/
ZRu4wtkS45SBQemxEY2CmSA/nrdFOrzzpaFZ1kcWsnIVnQ8jfSAux2oFxKP7OglDH1nc6b6MDrh7
Gqf9MD1m0hH1MILEdDULhuxyAG2Vkqrw3y8uAym/5dxnwrZlX5ND7h5PaXPxdiV1Qg5yTQMZexXA
sNjLoV+bbwdXZ1m1PgRg2thLyoP/rF4SAIWtc1qz28jlg3TDIW/zffIwl+fwnGVW0w/8rRWIjhS2
Db/hlIJ1laOl8Q4bYsJi18LJEL6O4mfcH1kgdzJzlLVy2frzVS7cxfVacx4sqjAqQc1MrNAu7IyA
jSOVp+2geEve0TntBhiLOySbGNNpoxJV7eyAqK435D9TALWLK0XpfFltDGxLenvQboaZEkFmVR5I
nq6BgtJo8nYju5JeedcOjiUMaKc9TaxQ0+G50U0ULKqdfvWzwIEngXUa8nU/7gEV6YeRQ6CiWYVj
GUmVNIVEGFW13nrFLgE8T/uPKOggtvlMYKNXjNcs/jSxwjwp+bCplDYldVH0LV4jA8D0e3wUjSBZ
jjKmL73LB3bN1aquISNffjnHoYAwA3QNBlEA+nOBlEfRP0IccbkY4rXBgjqTElY4HqsboMJRTPPh
EtW43Eeq4oKY3DKWxSqdzctPKnzfDj1Y7OIEMxNRFpY6X6z0QtbpISEaoor2C9NZMtItHA5JL7+F
BB3wbCqEZXNxkI6h+cwx4vSolKvf8FaEcTDpjq0T1XlItKWF01HsBIeH8lmsLIDLgO5bpPIl275N
VMD2K/neBzXvUhLkaUpPV2zoSA9K195TQGT0EO8kAp6/LDOeITN/VzNfI55m7G6U/9qqIxyRd4yo
x++7wORchygZCaD1im8g3qn6DMzTMM38z1+WGTQjr9G9LbiH/uyqVC5ILq9rZcKzuLrjc7Qy23Zk
s1wNSVy7mH8PYHpwI6R0PPfs9UanUp+R4UmasjJ4A9H0pu0uQst+c1S5RbtLzyZGuo8UK7na1PFF
FVUWtbQ0+7JlddEgE2k2hII5q8TvyCUvz4DCT1FalLmfvv/q3ukUzv5RjpejjUWf62RU4ehJoBxV
akcwjcULlmBPw+NA0NpyQp5EcVGaTcnG7rdzGA/rFZKTPQBP77GbkFp4eg1oLjQvPXmFMx53+lSq
kLt2G9r6Ynp2db/vZCyrqUbK5tElmLD0f/ozIj8ZGVNpBipPf17p8xl33Yd5by9skYXX7yaO+TgP
H1mHAWhuvsd/SNdmVbL3oguNStqY6FtyAvbKyKROjrBzBlSIPq2MQHgk0TcFfxb1dflnSC/+ISe/
jaQ5kD8bm4twNRDx4UKKJFj4+aMj+bvXfNHwrmKNq7zbYMBUuc60eRtznPuEKTsOXD7uTmSPKq3z
DAdGJrTiY5NHAVKDVJJo7FOmHEvsX48lJ5SOUgyDINT9Uw0qJRBmJY1JXd/Xlrs+ZW4E/aplMF1P
q+H+M6LCDWHGB9SrcKVPldXC+RhGQB9yMRpDNatzlf3GiJABHNuLdP8RbcazKokrCigcgWvYAiBI
yWyxGzI9SVcUsDISIQ4dLc6jRaN5TGI59PZXWeQj6SEWMMzv2Vz2PRhl849DdaNJXPh3PsALu4S4
ZjmfRiNE4x1T59xu5tbskv1iKC4UsIE/TCvejjFpdNOp0YW2jajqCmOZ1zGVLOiRx3gBXmVxLvN2
RsW6cxgGEEbvy/jOoxlJB028j/9pqmPj9UZRxdHLXcmbWyz54cfGL/Hb7mxKpwZeKIYUthPDGFv8
9/9OAw9dC58bPR7g55FJtOm7S++onIT4ddQl3BVlVFR+vAC9RJfQQWgxhugHj9l6VV6w/n3/pKk+
qDZnVsU1apZELJ/jhkwZpsy11VxpFkds9I4z0XNqgyw6+VxFeBBrnkq6uJ+xQpH/PzTYYYDPU98n
8IRe1GhTQ+9t/pftf14h07/zLERVO25TuMUVzBAg2sxRNTCovL6lQQ1gAvQ4iJLyeFf8HkLSv/O8
iRHeniI78FnDO4Q32NI1m0VahpMQcbQqbNgWrWm3BKoj4p/0R3FmefNfB4Sax4ljgoY5WhVjLEnl
27xXwPfdmuC+JLDTrJZSBzaBYD4vgd2yyrSIxuieGCiGfNs7KkNLO7l//h8AHilfMtSs5BDvt+WB
juL31yx+q9SktqeP6Qcb8Rg9E35IgqTZ+TY0ynI0EsGfSH+WvCg7BZ7DrvvSOy9ng7v1ERPrl94w
izXFoRRTVusiqe1hCyY1lkcN97LiI41iOMN6ANutJQ53Ncy2nG3/HlYG0XtIv4wn+KVbbS54/Nmn
vgEBfueeN++LOiiGvIsqfdSSwaKXwMZlPPvx4/VPe1ysI2jDTQgjDmMVVAwyh7t78bsG7wro2Zxf
G3DExTVBE1q0Zj7EBWkRRy7QXTXEu3qtgHPRGB8M5Gkh/i9A94ULPd2KYvSZsckqpy/h61FPOr0w
tXxTyI2wv52nqTHweoeNk0AB9XiO7DmdNbSsDR4NTQ/KCqCj18csdbY6FsfTIGfFIGLYf0a1Dv9n
6TNChIQjc46tQECDIAHZ9AimaDG/JTO0tJWYpjDKMqAn9I06s6gGZFV3V0v625xWdwWbPGGFpqrn
Lm/24vG9AAkCEZZ+pDO/7CFgit4MxD//7mru+9ZDTbaHHDUOynaHZhvp2ahVkdut2bv9k1Qh+ONV
1Y6QOWk4uTr3ChbzeQ8A