<?php
$lang->resource->report->browseReport  = 'browseReport';
$lang->resource->report->custom        = 'custom';
$lang->resource->report->deleteReport  = 'deleteReport';
$lang->resource->report->editReport    = 'editReport';
$lang->resource->report->saveReport    = 'saveReport';
$lang->resource->report->show          = 'show';
$lang->resource->report->useReport     = 'useReport';
$lang->resource->report->crystalExport = 'crystalExport';
