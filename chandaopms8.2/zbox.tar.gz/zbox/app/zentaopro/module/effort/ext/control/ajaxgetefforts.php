<?php //0067d
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}
$documentRoot = isset($_SERVER['SCRIPT_FILENAME']) ? dirname($_SERVER['SCRIPT_FILENAME']) : $_SERVER['DOCUMENT_ROOT'];
$link = is_file($documentRoot . '/loader-wizard.php') ? '/loader-wizard.php' : 'http://www.ioncube.com/lw/';
echo "<html>
  <head>
    <meta http-equiv='content-type' content='text/html; charset=utf-8' />
    <title>error</title>
  </head>
  <body>
    <h2 style='color:red;text-align:center'>未安装 ioncube loader</h2>
    <p>您需要安装ioncube loader才能使用该功能， 使用<a href='$link'>ioncube loader安装向导</a>。</p>
    <br /><br /><br />
    <h2 style='color:red;text-align:center'>Ioncube loader doesn't installed.</h2>
    <p>You haven't installed ioncube loader extension, please visit <a href='$link'>the install wizard</a> to install it.</p>
  </body>
</html>";
exit;

?>
HR+cPmmEw1JntT1RDC1zDsJY7IZcsa2O1ME4YlUynwzgqWH3nncogo1iGKcc3tKsXhMGEUA8ewW9
CKUobF4r79Gdc2DURGusItuNhE2BgMlETjqdZbKFmNjToOwzXPoro+jOeO8Yw1ug4iywU94m6WS1
Z8anXQpaTYKXuySnyTt62+J+j2JeQNK+RAkjWIIYlugyC1v4aJEccvAn7nfpkFoW5WrkbGHg6WC6
2l1CLJUu1JsyNyXArUsnLgTQRl2Cv/CBroIAN+VfEBuJS3gcGw+XCOm7ZRP1j9Bv7MIUfmJ1unmG
+XDMjeRnHIvBFULi9hDzMddNwRXhtnYHizaxFqfvXDCBsrXJdN1+sXSNzXhpWGQN3DGIE4++FJSt
to/uzhw75uZh2aOk5/g5LL6RDxKdurd8SIkRehaCHSKp/SzXTibNdZebTEdtDs3u/LHHAs2i/QW3
dyVkoW3imVQrAQj26/iI12lRWdvFsfe/Pl1Wzwql4RehrbFZ9jI+pyZBVHVdVVxdYUd4/UHFunJE
D+8MNvEvf2wFQRPyI1orSEc0Uc1K65skn5rZN/D3FZ/zWX7+nyqQocBk6RZFWfEOLH0zI8kTqLmk
yuMco7g0gbaeFiYh/F/E7Lm7oaW1fciJt5+mUnT4UenJNK1plIMDNJVVVZZ0dOK0kRV+ukyGjSBD
GYrpNU+u/CCZAkfrgOTP8pYRjSx8Xrr66nRA0g9ZECGpmAYu4sT3ufNKiiowGNbspRVXSWN/krBK
Ub1PyEbNPpLIy/s1u+/uAYg4nq3J/p5qnxR5stEIOEWzhP/8FIP3ZgaEZaVf0IjhNztfVQcfyGqE
KVkqhm8LoTL5O2nop32YyQBtt9tzEQx8kPpUtM9ICzkbe77M+mYUOlex+liby5BGad3QaGbnj2ej
NDPvWD4XVIoGblfFUU7CcRDSMJwWt0mumRdbG8HlarO6YeyHgblG7ajcU09NGP1bpzOg+HxgmIP4
UCviH/lmcYw0CKWOj00urFf0xFSdBbVA2nqz5nvkyIvchk8WGV3s8ZkyCDwpJo3/IK39cWfFxkTJ
ZoX4e1HiadzoW7QjVwNU4PvQIopSkqrt5O4Sb18+A0iTWIb+hnXHFP30OUNwGCNbXyq16AHVmH8F
COnrCbeYqxXWbKW0KVUA++ew3gARpm8swkLpAaSRQHKQK+cshTvFAfDWjGdX5TeWtaos9+RkHPcm
Nm6lWfd+jTQ7KUf0hZ+H4a7NVmen2gQphnFCp0choRb0+WOGkoES9DMLW5rza7wZrGOZA3shprYU
6dobq/6DPPcQUDc5Av0hgRCQHhbYZo4tAvPbKULVa5sWRTVha/ysmp34LMPEkMgANGyujx0vT/hz
xd9ohjsb7XY4oTQJxLla9jVQ2E02HzptPunKgVtuKPHrMp2WzjHvT6IAhyW4YchK7KGQNbCJwVI5
1MkSBhiX/frQAK+XWsyfKGwDodFf1q+MvQ24Wz5NHlg4vMAiWCsyLxct7djSRBo5mibrVRfG7k0j
dxACu4d/a1hBfYK9aKQTR3N0J6OO6dC9GMx3HZKf+aoqdNRge2tr7gqiR3QnIqwdgg/w+eD6fZ/9
creSx+2Bcj1upUU9Un8+4+zVti4xd2Agn0GMJ7gD2PRjhAb+4PwypJ++QKfBYszgNltbBSYwMP6N
gVVGiWSkS8MURGvv9hk3lX1LGq3eXvvl2xWfAUzYnpM5qtgwlNIeB5OlH2IbDuRq1rxODThpIwC9
A1RkSI9/XWhvIf0PKPq6iUy4Nvj9Oz5BLKDrMnkAxXS2QqTGRx6VoaOF9Q+GxtROGn+/9CbQye4F
9e94rCebrUYxbCTTG+o9JCCDtYefjmuAQ55g7JY3liQML7vBfKMGyoO4fct6j6UUYpY4ZJ77FqPB
Y2l/HvjWwl6Jo//vor8QkzrMQ4dJD5d8MTTttVvKCrGDcP3PKu+2H4SJC1MssAcNuQjTUVpQsd1n
w/zzkc0SK8ZoT7Tb3jInj9cV2ofQ9u5Pr5Yn/Lsf0qumrsyg1sxVZVAyHEMDr9AdT4Y4RToZzITM
vM96dYmmdd4V1G6fPEEk9SOALSPe2edD3oWhqDrQLK1ZDGX6ZopiQfdMc4hII316LYWXfSUxD9ny
rfQRcc6gXtcRRH3/sfJSrd7+igB7Ku3eqjsdCnE42SVBrVlnIrNAMrC0TN0zcmen3+HLR4S0KhJY
81r7ZTCCQhORXg6fRv2+j9U+3K0SPzWrFRH/DFhjVSigJJWhsXhsMtmfEtccssHA4XRgpJAfNump
nFfaQfZBRz1cOeEjlPV0d5DYG601RScmp5tmc3Sr6hZoa/6HZMqsxvSSfskF6lF5POAwM/BELVBz
HMoCEDhe+siO2yebQvMicKCgGsz8IU2xN4tlopScJ4n+tWBbBzK4shnYjObDqcKq/osodDIDgM4J
uCGStQ6Qmtk7bqtuDNFBD3NTe7/N+ZRDmDIX7fyWkk/OLDbdOUwu8VyHP/toU1t5k1kKdDYnR96V
1o58dl2H83DJO+96urvh2hs9k8K0T0WnbCDg34Y6cubWfRQPn42u5yj+eyWSaC/mcbZj+Zu718Lj
Qpwpo/N3DIShB22jQGyLeOOa5fvBWep5ShjvrQKvWXPVYKqPpTBO6Pu9LGz+FeEqn1TQIAnMTCBL
xNWORbLhMn+fP/dpejcHcspYw6uUqSq2WYO02BMNlnIZTr6JMYFunY0ol+yrNGw3IX7nOoocY3lm
xfUqFJwp+EAoBraAtNOSfeGD75qxb9szgsFS+GSoFdWVD29NfNna2aKnksnXhvrGbxkzp2qtj4C+
lqFRL/1sp6L9GqG/tMp+/1nW0+hryPj67CeNwgOqB1CreK26Je4wZ/jtfNwe30dh8GRNkK9IVsqo
9D0z98F6xijL5LniB+4VTt4a+OghxZPJ0KZjGkb8IwzHQho6IetGwKnPOXwvTg8dh9FcxPq/rSQq
Yn4wdyBLqkBi9e+e6uE92CZ8mVLZoDXGPhLQ2sgJGbA9EsC/IpQjTmVD0McJ8R9+ee6ecquq4mmN
rxR5KOdsiV33Wh3toDCYRcqZSIpGvvSG2RppLcLVN4jSXIzmq4RX6ql+d/iJXE4iZXh3tLumzKVx
yJ3TgOe7d+el8O1zXnyFc9yji+ybK13XMbrpECbhmYpywPh2P/Ch5x0Zu6awEGJi/x0t09wBL539
1SAwkqnkfcfq8HwhB89rZ+KcbmbupmsnG5073yw6k372i65x1C6ZBem4eZqCVubnUCJOo540K3Re
Ov7Li7s+lSm1aQXT5axBzif4WY3jRwWQB9zWw7twTuS9viIUnAJlGkeUIwLbbVViCVTQHVgXv857
eucgM8vpwJJkFhWkdRDnNl7JMqQ2HH1BeVLewPDY6TtnYr2N1759YuoELIHP4Q59f3Mfog7n5s+g
DhGEusctiCZZEZcfYclBlRFPNbCpeMygZW2nbuerAqnE8zaSa9bfwPQmwjTv/JUPmDMxntjyzDj6
YCI8yvf1UJqNwVcgMX66DTUJEeRLK2KtlEuglJ52cGOKb6T3fbGTFhqCWEfLRe5WRSJcRRlxOd17
80hAf9/uqOlOZ25Uz8kQXFIBaqexltj2ozqbW8IhI9GjNVea4JWLvVIVyhv/tibZTE7uW6m2dGB9
SyySUEK9sgrv+19RBmw/D2NXIx+SqIdGAPYDV6yhR5kMQOW1GnVpFfgE47YSXA1YweUHSv1g5kXI
cU+YUEXzn1YA1F4NPakb1xTqu/vhfhBHWU9xxr056E+edvuOVVIKZvcdgSs8NtpvOVOW4dGLqlQu
azHyYKSGkWib5mt5ZA+7m+vHGb/syMvX25AkGMCjVuAdsNQ1YlGfzRk+MpGJLs/vSuC+1U7DG7ev
deLeQjSCTT+fIfkYTD9pniJIkDAEMT1KRuJwNJKAp7dTIcktDq2dRriYOHcYSW7JvOR2Yp60MXqm
4PiBD/fp6zniQkyKkyrQQ1KKiiC0aPqkwG3ppEpPAPVJTB1ife7yDfa0mwWdbYv4/BNwWtw8mu73
NIyu9mA3+XTBVSlIHHw9YyH147ak5Vq9b73kg4Y+6lsyXZAWLG+e4VKk9/DwpnAy79qx2pt58tzh
bhrdVIJHCwNnjA+czMqpB7ahuTWw4JT3qUv0PdYDHeu642vHQpPwawlKTJZ3BFRCoq428euHte+j
jXo564a=