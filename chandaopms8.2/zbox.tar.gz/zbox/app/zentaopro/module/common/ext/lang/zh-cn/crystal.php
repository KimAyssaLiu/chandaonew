<?php
$lang->report->menu->custom = array('link' => '自定义|report|browsereport', 'alias' => 'custom');
$lang->report->menu->create = array('link' => '新增报表|report|custom', 'alias' => 'custom', 'float' => 'right');
