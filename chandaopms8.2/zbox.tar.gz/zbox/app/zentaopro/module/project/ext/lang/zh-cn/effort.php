<?php
$lang->project->effort = '日志';
