<?php
unset($lang->misc->zentao->about['proversion']);
