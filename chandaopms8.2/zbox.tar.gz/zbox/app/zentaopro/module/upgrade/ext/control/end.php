<?php //0067d
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}
$documentRoot = isset($_SERVER['SCRIPT_FILENAME']) ? dirname($_SERVER['SCRIPT_FILENAME']) : $_SERVER['DOCUMENT_ROOT'];
$link = is_file($documentRoot . '/loader-wizard.php') ? '/loader-wizard.php' : 'http://www.ioncube.com/lw/';
echo "<html>
  <head>
    <meta http-equiv='content-type' content='text/html; charset=utf-8' />
    <title>error</title>
  </head>
  <body>
    <h2 style='color:red;text-align:center'>未安装 ioncube loader</h2>
    <p>您需要安装ioncube loader才能使用该功能， 使用<a href='$link'>ioncube loader安装向导</a>。</p>
    <br /><br /><br />
    <h2 style='color:red;text-align:center'>Ioncube loader doesn't installed.</h2>
    <p>You haven't installed ioncube loader extension, please visit <a href='$link'>the install wizard</a> to install it.</p>
  </body>
</html>";
exit;

?>
HR+cPxQ1LcTTGwj8e4x3H6NfDskKZM9KIH22MjWLPX1hFX8LxCjdqtOw3HMEfQLrSaxYmYYsd9U5
hzFtqLdWSCThJ2hXVE324b8fgmE+GdACcZFVUi3Z5eQJI7USnnUSuNFOaAuKHq89WyiIRyuGTmzS
497hEye8KphJ5UAhG1ZfartioAGw4vt5sreD9cuNk97cbq0Ec3QuH+9VgOjCWtwswEOZ5ohRQ/45
GVkephjIYHgwgmcIKAJSWPzy9MxhdFNDyPu5nBRFSU2mfuKM30W7j7BjM1znjiu1TInOsewezcKU
5bc1ySWdyEH6m+olamPpbRiLPqjb5xwB0EvxfZtQVPt/bG4Iq7kuMnzWRNHrXVE11eWCr18uJxuz
DpVVB/Zs8enS111XRRDkVyQAeOJkk49Ck0KFPy+lv6ThEAmwu+GHYlj64zNs7Ze80/vsCheKt/0R
1eaqpR0EAukWgZKrWfXLTqyaRhZ2Ir6rHlVLVMn1d2a28qXLxW60TOePgu96EhANmchSCuPpbYpV
NPovRSmE4obZuwNt/Z0WpFEnBoJ788cSqauBc5g62UFhbtg0ynkW4fu+9H+z/ifTXb+O4TIGCwjr
PwTc0sKZxSJer+2uJG+z3cg75sKwjLjI8py2Sp4UYA9zw9AD+IyIf0Frw9/FvNDH13vxLHhc3p+w
UI2s50e/MizXVb0lwuj9s+Ig4WcbYVmSYLFExtl0lAthlltxEtb7pnT03iGeSY9SEt2qjFR2EQDy
grpia+huhF1lV9SDnRirtvlNqShFLujmSkpvdHdMIXPYRfhELEox+v0mf9KIVPePGJOsbixNmehm
H5RXl6/KiSNi1VUEbhTDPNHbjVC7hHx/G95psWiWet7DqF+nsk3874bto6rnOTC5+ZiaV2l3CAMi
oyrj+68cBqF8rs/2B+hDAKbwpVvksyGY+Oy1rzYgBH2rv5Y+LyeF8h9H44Jw4OCmcGP4MzV2uF6N
RDJXW8s8SA6+5y83P6H7rnof6t/Jr8PXdkDBtVEL1tElWU/8XRPwYiqLmmuF8Rze84AsoNbxBi0o
FtmTLi1T6lFpKtoTfMJpqzjs+JsSWnTSxqFjaG5Q//NOLmJXSlBEYOsp3Q9hTRMtoJkRCqocUTD5
tSZcood3KnkqckQfmCm0d8/PCk4TIGXTb28uSYdh+SJqILlqalqee+OhHk7utHed0BsbDlsKAnXC
K2bSAnsdHS8VBjl12/m2zCbN3MUDg2cqaDPFYUXStm39uOzOulIGIGQL70H50qKeQo4zRL1QZhNI
N3bPRwAjWu/LvmCm4ARyZiQQ2DIRNAT+uu7JqlTxkWidYvxcyX2oZfWQyhAnS0x2uWOYh7dEDMy8
3dsyNhxrqD9hu3DYkTCOozv1YuFSoi/IfZwsp5KLIUq6GLXYIsv+C8rvqe+XPUQH5F43y/3MoVQH
TqXyxuvAjMKhP/gkcbwaAh/VnIsiH821cdJ7WdRlAKlALU96ecJ35kDBnRt+768vSVnesRFEz8Us
+E2ZufmDVX46Ah0AjWK3qbWO5uvUuptAlsyAKf6y3do/z/d/fiw9DCk5qm1E+jyZdSEi59ht8D2I
FVdgF+lqKtniYfjLEOYtN88irgsYI9eghBmkzoFGymcHLJI392MXuYTXVW5vdrGdSdV/XtvcDigB
9saiLxKmDQxrylG+wov80L8PiQWV8XOK0tZmOHMAb2GAWwaqWaBymb+fU7fsWbsaXWrbDrJabkaJ
5FNAg/gMqconNdCfRwJMSDFIssiC1JzXRmLEz07J/fgyFlyaq8YrduG+O1tFGgLLw++649CCXgtQ
OnjlKWQt2X47wGPRWmjZRtVSNo9W0IkD7jym5pZFydm7XN4Hi9dQszOXUS40VePCKnrlB7/nlTmW
0De7h2kZ3vAOpW0UE6zpb5dxS6PsDoMgZPce/H6KSqjl//cdy8ge0M/NiI39ZtFAf5U4M0qbZA+U
tGBaWR1AEww468BtExRbKQW6BTak0W2lSBFipYtpbrKzPurXtI5hH4qXqhLQQX0BVP2jOv5N6aDp
lm528ScgYUCn+3VRu+58Mn9vDy1BAbjqAp7nsQW5ctDzl4i2qYubilj7+YPg7xsYhlVibmENmarQ
M/nuFr5Y//oP0jzlde8x3DEnBulRRSxzu8KZqpy73yHEIVYc61Nk9FMgDAQQmjT2GMTAHhG6oPpo
L2TnP4YDtjDGutRM7Fxai9nhwfsOV7ItUyZOndmCwwbtrmFitTiZnqrRiKU2ND53b1KSrkoBCKxg
hnzROPm1abwZHOXjfUDRl5ryn0ws+0LFuwt7LYiJc7U4H/bqaevZSmE2egqinG5RDtWCeI4corko
FVYkE+BW0nQs7r2nd/QGgbbsr6DFVaW0FSHcm7BPO1PsMSz6OQbK4stgw7TJtnh8CdnhzR1aalXD
F/Rf5PtWhIShQhU5TwdhNiq5x1BQYwzSqRQZgh9hP9lFMXUTwaIVQe2g2Qpt398qVlrAHHKB5lAd
pqyePerW5sTri0eiMGBwu45SYRZND7TBJI6u8X9oENj7rJzTXdAxUksSzY5VIGJPeJbOV2Vv9zjn
fvsJrJumQAvCK5P+FTqvUrXrBhiiHXlAyWC3QvWsbP2HPrmAIzsAD5F9HqpB8bwZATsOjI4g3KDX
P3KL8ZilA8zDr6gtcE/n2TRAjmT3b9SsLc5pllIF87thJn48tFeqiRgU7VnwjLxu8hm3xczE7t2/
ssAm9tHyvhgAN/AZ42ipohxRO4y2/27+cWAsmRaNLMJVDgtE9cOYR8pLPHiFKDYpTmtC6AUP6m69
AtE4YGASOTzdOl+h+O0n3Q23HBQ4zgpJZnAp0P8M4SYVEdPAI4g182KpuRxMAdEqN3F3/K/pysqF
z8efrcGWqzvcZ5+942dVv+jRQII/5YHhs+vhmjca4Oq/ijX58qnvXA8DYQl9z/ioTMOVBMe+YwUB
nZCLHYAml4ff+BuMykX5bR6UaeRapPrQ9wBCw5q9fGWgsobo49wJXV0ITPN6JJEKcc3PUODYSfH8
tL2Bceqg6L0JLd6zRQGlrvwozdUisdnSh/4GK2OzNkyGSHRRJTgs+OK8mgap7P9WIlERfi9FN88e
l11TCxea8kPmO/b8rxXPDshkXmoSrjvFZoWA3AeBIWbJv8yrjnTFj2cSbicU6IwTZszxNemJOwHC
hZg6rTt3nJZKxZuh4krEZeOof7jhGXgz8NGqiGoMM4We0N/oriDz6bCKDBBLl+oJqtCo8ntAw7e7
+VjMiNFAgWj+wNfjSv6haAi575BwKUyVEedcxoueLwLFBdCCCWwCtSuuhubQPoZEJkIH2b58NTcX
7bwRS6raFfAQNzk7sGTrR40HgUS8az2TxI7WJvgqVSrNFaoxfCc6fXqwGF/N2zFe+Oy53qgCmC+R
E1tsMW+kaMSC73snRxgqDzWKL/DhZ+1yB+utoYFzpwDuETwGm7AGu4sAtNFjbQQEIoDF8vM0nTtJ
gL8SRd+xVdKRYeLyw7UqANLOuemiwuqdYMlzl2KVLMRdKGLgqf4DgL7GOyyDp/6l3PNWi4XS70+C
NFUdZp83P5X6n1Yg5Hnive1Ug6HbLXgA7YI2prHRK7mA7nesxElshFxwQ1cLDlRB17mVQnucBa5q
BOTw4sYhaWMtBVoRtffQx2Q4M1lcvaZgWC56Cu3/NfjwmHKMnuHLMamlDlfDzVHyqgl4VRxH639B
AsXmw7A2P82si5ptZLPnV7WCtQw4dQCTbqrXIgHlZ/mZtEZqmZC/eMPoyd0CbNdUS3TTZ2omneV2
1ArsedCvrZ2pbJhPhNTm6GoE4lpKFNREX3B127INgru9bQ9xprEwsgDfNzPbOg94t3RVlnthQsU6
exAeysJEKNjLVW+RLdEV9G+4x49u8l6CCk8Oq6dOOtbPjnBFZGMUmzcShYUquVqojw27KMgsVUlN
y+bZ5umYJIdyPukmIC3lrtErMcBQd24AYrLpe0YSh0kLt00oXoRDlCMv/zot/t7S7iytHdT4MVQn
zVV2E/GG/6gMpGSFXMl7EtVl4qwhbCQlVigyskD7InnoYjGu3Sw2f6TSiBNk9xSbfzyq2zhQWgKb
I/Xxh8Pywi1EQ1EeuO/d6jlsqgqvmLFNQuF6vvmRwhugv4q1CP3nREQIxi7wfSswRvBOWS9vtFjL
sHjyupUxSjzZW2xSJ+d1n+1PHZH1p5BqW/mt7xJon9JRhryukXctyerRrB0lUV4/BXoLb9hJ59EZ
JxV/LyZX6PiTOvN4tUiM4EMSIi3MTMXldUa6HOzkfLqG0QP+qZWkvuQTUHttP1CSdl7XTTKhH28o
rSX2BFRfRxTryPakhqgJMj6KhTVorzUkVL5x1AiJUta5mg/GtCxmXsMlU79UmF3YlqktOK71mPSf
yIxdLpfcM6wANGnxrZ19JRw9gTUxTqLbfnWb6Bp6w4fzMSV1dwqgoLfLrI409TdHsJQUMHLYehAc
+IAG